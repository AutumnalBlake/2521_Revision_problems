
#include <stdio.h>
#include <stdlib.h>

#include "Graph.h"
// include Stack/Queue as needed


void importantRoads(Graph g) {
  // TODO
}

